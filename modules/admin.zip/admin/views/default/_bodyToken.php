<h1>Parolni qayta tiklash uchun sizga url manzil yubordik...</h1>

<h2><a href="<?= Yii::$app->urlManager->createUrl(['admin/default/token', 'token' => $token]) ?>">Parolni qayta tiklash uchun bu joyga bosing</a></h2>