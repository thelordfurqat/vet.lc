<h1>Sizning yangi parolingiz</h1>

<h2>Parol: <span style="color:red; font-weight: bold"><?= $parol?></span></h2>